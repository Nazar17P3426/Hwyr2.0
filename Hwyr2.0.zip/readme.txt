Hwyr2.0.exe (translate it to english to see a word)

Note:
this is a comeback malware, but this is short unlike my previous malware,
if you understand what the name of the malware means, then luckly you
don't have to use google translate (if you understand what the word in
english is). Please, after testing it, check the source and modfiy it for
the 2.0 version, if you only have visual studio code, you can use the C++
file to compile it.

Information:
Creation date: 10/30/2023
Duration: Long
Releases: 1.0 and 2.0 (soheil shahrab's), 2.0 (mine, but I add some new effects)

Warning:
It may terminate dwm and explorer and also overwrites the MBR, so, if you
use Windows 10 or newer, it might not work, so try to use Windows 8.1 or
older and also, it repeatly terminates task manager and command prompt,
but you can use powershell or a batch file to terminate it, and it's not
for people with higher chance of seizures, strokes, heart failures or
even brain death, so, if you have one of those that has higher chance
for you, please don't use it, if you are ready or OK with a older
Windows, then you can test it, :)